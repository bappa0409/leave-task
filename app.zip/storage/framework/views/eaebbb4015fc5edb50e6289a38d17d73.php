
<?php $__env->startSection('title', 'Add Staff'); ?>

<?php $__env->startPush('css'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>

    <!--begin::Card Header-->
    <div class="card-header mb-3">
        <div class="row">
            <div class="col-6">
                <h1 class="h3 d-inline align-middle">Staff Section</h1>
            </div>
            <div class="col-6 text-end">
                <a href="<?php echo e(route('staff.create')); ?>" class="btn btn-success">
                    <i data-feather="plus-circle"></i> Add Staff
                </a>
            </div>
        </div>
    </div>
    <!--end::Card Header-->

    <!--begin::Validation Message-->
    <?php echo $__env->make('include.validation-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--end::Validation Message-->


    <!--begin::Card-->
    <div class="card">
        <div class="card-header">
            <h5 class="card-title">All Staff List here</h5>
            <h6 class="card-subtitle text-muted">Highly flexible tool that many advanced features to any HTML table. See official documentation</h6>
        </div>
        <div class="card-body">
            <table id="dataTable" class="table table-striped" style="width:100%">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th class="d-none d-xl-table-cell">Email</th>
                        <th class="d-none d-xl-table-cell">Type</th>
                        <th>Created At</th>
                        <th>Status</th>
                        <th class="d-none d-md-table-cell">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $staffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <div class="d-flex align-items-center">
                                <div class="flex-shrink-0">
                                    <div class="bg-light rounded-2">
                                        <img class="p-2" src="<?php echo e($staff->profile_photo_path ? asset('upload/staffs/'.$staff->profile_photo_path) : asset('assets/img/avatar.jpg')); ?>" style="height:50px; width:50px">
                                    </div>
                                </div>
                                <div class="flex-grow-1 ms-1">
                                    <?php echo e(ucwords($staff->name)); ?>

                                </div>
                            </div>
                        </td>
                        <td class="d-none d-xl-table-cell"><?php echo e($staff->email); ?></td>
                        <td class="d-none d-xl-table-cell">
                            <?php if($staff->type == 1): ?>
                            <span class="badge bg-success">Admin</span>
                            <?php else: ?>
                            <span class="badge bg-primary">Employee</span>
                            <?php endif; ?>
                        </td>
                        
                        <td class="d-none d-md-table-cell"><?php echo e($staff->created_at->format('Y-m-d')); ?></td>
                        <td>
                            <?php if($staff->status == 'active'): ?>
                            <span class="badge bg-success">Active</span>
                            <?php elseif($staff->status == 'block'): ?>
                            <span class="badge bg-danger">Blocked</span>
                            <?php else: ?>
                            <span class="badge bg-primary">Pending</span>
                            <?php endif; ?>
                        </td>
                        <td class="d-none d-md-table-cell">
                            <?php if(auth()->user()->type == 1): ?>
                                <a href="<?php echo e(route('staff.edit', $staff->id)); ?>" class="btn btn-primary actions mr-1"><i data-feather="edit"></i></a>

                                <a href="javascript:void(0)" data-route="<?php echo e(route('staff.status_change', $staff->id)); ?>" data-csrf="<?php echo e(csrf_token()); ?>" class="btn <?php echo e($staff->status == 'active' || $staff->status == 'pending' ? 'btn-success' : 'btn-danger'); ?>  status-confirm mr-1">
                                    <?php if($staff->status == 'active' || $staff->status == 'pending'): ?>
                                    Block
                                    <?php elseif($staff->status == 'block'): ?>
                                    Unblock
                                    <?php endif; ?>
                                </a>

                                <?php if(Auth::user()->type == 1): ?>
                                    <?php if($staff->status == 'pending'): ?>
                                        <a href="javascript:void(0)" class="btn btn-success approve-confirm mr-1" title="Approve" data-route="<?php echo e(route('staff.approve', $staff->id)); ?>" data-csrf="<?php echo e(csrf_token()); ?>">Approve</a>
                                    <?php endif; ?>
                                <?php endif; ?>

                                <a href="javascript:void(0)" class="btn btn-danger delete-confirm" data-route="<?php echo e(route('staff.destroy', $staff->id)); ?>" data-csrf="<?php echo e(csrf_token()); ?>" title="Delete">
                                    <i data-feather="trash"></i>
                                </a> 
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
                </tbody>
            </table>
        </div>
    </div>
    <!--end::Card-->
   
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\leave-task\resources\views/staff/index.blade.php ENDPATH**/ ?>