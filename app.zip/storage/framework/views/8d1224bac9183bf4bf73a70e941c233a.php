<nav class="navbar navbar-expand navbar-light navbar-bg">
    <a class="sidebar-toggle js-sidebar-toggle">
        <i class="hamburger align-self-center"></i>
    </a>

    <div class="navbar-collapse collapse">
        <ul class="navbar-nav navbar-align">
            <li class="nav-item dropdown">
                <a class="nav-icon dropdown-toggle d-inline-block d-sm-none" href="#"
                    data-bs-toggle="dropdown">
                    <i class="align-middle" data-feather="settings"></i>
                </a>

                <a class="nav-link dropdown-toggle d-none d-sm-inline-block" href="#"
                    data-bs-toggle="dropdown">
                    <img src="<?php echo e(Auth::user()->profile_photo_path ? asset('upload/staffs/'.Auth::user()->profile_photo_path) : asset('assets/img/avatar.jpg')); ?>" class="avatar img-fluid rounded me-1" alt="<?php echo e(Auth::user()->name ? Auth::user()->name : ''); ?>" />
                    <span class="text-dark"><?php echo e(Auth::user()->name ? Auth::user()->name : ''); ?></span>
                </a>
                <div class="dropdown-menu dropdown-menu-end">
                    <a class="dropdown-item" href="<?php echo e(route('profile_page_show')); ?>"><i class="align-middle me-1"
                            data-feather="user"></i> Profile</a>

                    <a href="<?php echo e(route('logout')); ?>" class="dropdown-item"
                    onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                    <i class="align-middle me-1" data-feather="log-out"></i>Log out
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                            <?php echo csrf_field(); ?>
                        </form>
                    </a>
                </div>
            </li>
        </ul>
    </div>
</nav>
<?php /**PATH C:\xampp\htdocs\leave-app\resources\views/include/header.blade.php ENDPATH**/ ?>