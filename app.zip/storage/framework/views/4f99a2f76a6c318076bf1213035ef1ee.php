<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\leave-task\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>