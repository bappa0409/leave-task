
<!--begin::Google Font-->
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
<!--end::Google Font-->

<link href="<?php echo e(asset('assets/plugins/jquery-ui/jquery-ui.min.css')); ?>" rel="stylesheet"/>

<!--Start Date Time Picker-->
<link href="<?php echo e(asset('assets/plugins/daterangepicker/daterangepicker.css')); ?>" rel="stylesheet">
<!--End Date Time Picker-->

<!--begin::Theme style-->
<link href="<?php echo e(asset('assets/css/app.css')); ?>?v_<?php echo e(date("h_i")); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/css/light.css')); ?>?v_<?php echo e(date("h_i")); ?>" rel="stylesheet">
<!--end::Theme style--><?php /**PATH C:\xampp\htdocs\leave-app\resources\views/include/css.blade.php ENDPATH**/ ?>