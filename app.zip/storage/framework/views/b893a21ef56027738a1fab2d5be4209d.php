<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<!--begin::Head-->
<head>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Dreamers Association">
    <meta name="author" content="Dreamers Association">

    <title><?php echo $__env->yieldContent('title'); ?></title>

    <!-- App favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('assets/img/icons/icon-48x48.png')); ?>" />

    <?php echo $__env->make('include.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <?php echo $__env->yieldPushContent('css'); ?>

</head>
<!--end::Head-->

<div class="wrapper">

    <!--begin::Aside menu-->
    <?php echo $__env->make('include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--end::Aside menu-->

    <div class="main">

        <!--begin::Aside menu-->
        <?php echo $__env->make('include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!--end::Aside menu-->

        <!--begin::Content-->
        <main class="content">
            <div class="container-fluid p-0">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </main>
        <!--end::Content-->

        <!--begin::Footer-->
        <?php echo $__env->make('include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!--end::Footer-->
    </div>

    <?php echo $__env->make('include.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</div>

</html>
<?php /**PATH C:\xampp\htdocs\leave-app\resources\views/layouts/app.blade.php ENDPATH**/ ?>